import{a as t}from"../chunks/entry.BtdoqUfR.js";export{t as start};
