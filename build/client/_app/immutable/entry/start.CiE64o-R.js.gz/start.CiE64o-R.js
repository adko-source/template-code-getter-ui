import{a as t}from"../chunks/entry.DHHFnwdy.js";export{t as start};
