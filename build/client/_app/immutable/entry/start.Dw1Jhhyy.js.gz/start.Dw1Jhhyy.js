import{a as t}from"../chunks/entry.CQ7bIcpm.js";export{t as start};
