import{a as t}from"../chunks/entry.ZXCmxyTm.js";export{t as start};
